create view gsporgview(id, code, name_chs, name_en, shortname_chs, shortname_en, shortpinyin, nodetype, path, layer,
                       isdetail, parentid, sortorder, source, note, creator, createdtime, lastmodifier,
                       lastmodifiedtime) as
SELECT gspsysorg.id,
       gspsysorg.code,
       gspsysorg.name_chs,
       gspsysorg.name_en,
       gspsysorg.shortname_chs,
       gspsysorg.shortname_en,
       gspsysorg.shortpinyin,
       gspsysorg.nodetype,
       gspsysorg.path,
       gspsysorg.layer,
       gspsysorg.isdetail,
       gspsysorg.parentid,
       gspsysorg.sortorder,
       gspsysorg.source,
       gspsysorg.note,
       gspsysorg.creator,
       gspsysorg.createdtime,
       gspsysorg.lastmodifier,
       gspsysorg.lastmodifiedtime
FROM gspsysorg;

alter table gsporgview
    owner to fi1912;

